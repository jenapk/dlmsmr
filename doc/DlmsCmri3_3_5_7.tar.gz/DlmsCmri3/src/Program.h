//FUNCTH.H

//=============================================================
#ifndef _PROGRAM_H
#define _PROGRAM_H
//=============================================================
int FlagCheck(int _Choice);
int MeterProgramming(void);
int ProgParaSet(int ParaMeter,unsigned char classID,unsigned char Obis_a,unsigned char Obis_b,unsigned char Obis_c,unsigned char Obis_d,unsigned char Obis_e,unsigned char Obis_f,unsigned char Attr);
int ProgParaRead(int ParaMeter);

//=============================================================
#endif //_PROGRAM_H
//=============================================================
