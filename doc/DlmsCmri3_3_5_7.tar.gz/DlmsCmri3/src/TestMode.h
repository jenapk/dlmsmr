/*
 * TestMode.h
 *
 *  Created on: 26-Sep-2015
 *      Author: mundel
 */
//======================================================================
#ifndef _TESTMODE_H_
#define _TESTMODE_H_
//======================================================================
void Test_Mode (void);

char TestModeScr(void);
void Test_Mode_TypeB(void);
void Test_Mode_TypeA_C(void);
char TestModeACReading(void);
char TestModeBReading(void);
void CreateKeyDetectionThread(void);



//======================================================================
#endif /* _TESTMODE_H_ */
//======================================================================
